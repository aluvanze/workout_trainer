"""workout_tracker URL Configuration

Points our project to our workout application.
"""
from django.urls import path, re_path, include

urlpatterns = [
path('', include("apps.workout.urls")),  # ✅ CORRECT: Just use ''
]
