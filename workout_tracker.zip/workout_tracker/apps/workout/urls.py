# """workout app URL Configuration

# Our workout application URLs.
# """
# from django.urls import re_path

# urlpatterns = [
#     re_path(r'^workouts/$', views.workouts, name='workouts'),
# ]
# from . import views

# urlpatterns = [
#     re_path(r'^$', views.login), # index / login page
#     re_path(r'^user/register$', views.register), # get register page / register user
#     re_path(r'^user/login$', views.login), # logs in existing user
#     re_path(r'^user/logout$', views.logout), # destroys user session
#     re_path(r'^dashboard$', views.dashboard), # get dashboard
#     re_path(r'^workout$', views.new_workout), # get workout page / add workout
#     re_path(r'^workout/(?P<id>\d*)$', views.workout), # get workout / update workout
#     re_path(r'^workout/(?P<id>\d*)/exercise$', views.exercise), # add exercise
#     re_path(r'^workout/(?P<id>\d*)/complete$', views.complete_workout), # complete workout
#     re_path(r'^workout/(?P<id>\d*)/edit$', views.edit_workout), # edit workout
#     re_path(r'^workout/(?P<id>\d*)/delete$', views.delete_workout), # delete workout
#     re_path(r'^workouts$', views.all_workouts), # get all workouts
#     re_path(r'^legal/tos$', views.tos), # get terms of service
# ]


from django.urls import path, re_path
from . import views  # Import views first

urlpatterns = [
    path('', views.login, name='login'),  # index / login page
    path('user/register', views.register, name='register'),  # Register user
    path('user/login', views.login, name='login_user'),  # Login existing user
    path('user/logout', views.logout, name='logout'),  # Logout
    path('dashboard', views.dashboard, name='dashboard'),  # Dashboard

    path('workout', views.new_workout, name='new_workout'),  # Add workout
    path('workout/<int:id>', views.workout, name='workout_detail'),  # View/update workout
    path('workout/<int:id>/exercise', views.exercise, name='add_exercise'),  # Add exercise
    path('workout/<int:id>/complete', views.complete_workout, name='complete_workout'),  # Complete workout
    path('workout/<int:id>/edit', views.edit_workout, name='edit_workout'),  # Edit workout
    path('workout/<int:id>/delete', views.delete_workout, name='delete_workout'),  # Delete workout
    path('workouts', views.all_workouts, name='all_workouts'),  # View all workouts

    path('legal/tos', views.tos, name='tos'),  # Terms of Service
]
